'use strict';

;( function( $, window, document, undefined )
{
	$( '.inputfile' ).each( function()
	{
		
	});
})( jQuery, window, document );