<html>
<head>
</head>
<body>

<p>{!! $mensaje !!}</p>
</body>
</html>