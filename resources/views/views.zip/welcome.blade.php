@extends('master')

@section('title', 'Home')

@section('content')
			<div class="preloader">
				<img src="../public/assets/img/devoops_getdata.gif" class="devoops-getdata" alt="preloader"/>
			</div>
			<div id="ajax-content"></div>
@stop

