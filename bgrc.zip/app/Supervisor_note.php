<?php

namespace Ermtool;

use Illuminate\Database\Eloquent\Model;

class Supervisor_note extends Model
{
    protected $fillable = ['note','status'];
}
