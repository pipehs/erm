<?php

namespace Ermtool;

use Illuminate\Database\Eloquent\Model;

class Audit_program extends Model
{
    protected $fillable = ['name','description','expiration_date'];
}
