<?php

namespace Ermtool;

use Illuminate\Database\Eloquent\Model;

class Audit_test extends Model
{
    protected $fillable = ['name','description','type','status','results','hh'];
}
