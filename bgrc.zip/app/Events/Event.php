<?php

namespace Ermtool\Events;

abstract class Event
{
    //
}
