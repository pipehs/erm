<?php

namespace Ermtool;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
}
